FrontEnd  : Angular (Bootstrap)  / 
Backend   : C#

![1](https://user-images.githubusercontent.com/47904677/117559014-5f8d4000-b08a-11eb-87c8-90cbb824d9ca.JPG)

![2](https://user-images.githubusercontent.com/47904677/117559015-60be6d00-b08a-11eb-9c00-4de8e4706ce2.JPG)

![3](https://user-images.githubusercontent.com/47904677/117559016-60be6d00-b08a-11eb-930b-a1eb16d4e669.JPG)

![4](https://user-images.githubusercontent.com/47904677/117559017-61570380-b08a-11eb-9b12-9eb2f90a32ab.JPG)

![5](https://user-images.githubusercontent.com/47904677/117559022-6451f400-b08a-11eb-9807-f670de58f2a3.JPG)

![6](https://user-images.githubusercontent.com/47904677/117559023-64ea8a80-b08a-11eb-9885-63e4544685fe.JPG)

![7](https://user-images.githubusercontent.com/47904677/117559024-65832100-b08a-11eb-82c2-f2548b13a4ae.JPG)

![8](https://user-images.githubusercontent.com/47904677/117559025-65832100-b08a-11eb-992e-68096b57a332.JPG)

![9](https://user-images.githubusercontent.com/47904677/117559021-6451f400-b08a-11eb-9876-1f5d93b037ab.JPG)

# RecapprojectFrontend

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 11.2.4.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
