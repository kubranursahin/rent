export interface RegisterModel{
    email:string;
    password:string;
    firstName:string;
    lastName:string;
}