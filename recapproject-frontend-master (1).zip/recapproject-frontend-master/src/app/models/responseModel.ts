export interface ResponseModel {
    success:boolean,
    message:string
}