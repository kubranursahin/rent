export interface Customer{
    id:number;
    userId:number;
    firstName:string;
    lastName:string;
    companyName:string;
}