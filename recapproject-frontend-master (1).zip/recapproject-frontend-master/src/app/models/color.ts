export interface Color {
    id:number;
    colorName:string;
}