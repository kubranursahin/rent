export interface FindeksScore{
    id:number;
    customerId:number;
    nationalIdentity:String;
    score:number;
}