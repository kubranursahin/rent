export interface Brand {
    id:number;
    brandName:string;
}