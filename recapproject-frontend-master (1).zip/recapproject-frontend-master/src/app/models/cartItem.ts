import { Car } from "./car";

export class CartItem{
    car:Car;
    quantity:number;
}